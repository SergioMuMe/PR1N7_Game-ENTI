::: PLACEHOLDER DEFINITIONS :::

WHITE cube -> Player.
BLACK cube -> Player Clone

BLUE box -> BUTTON, boolean, press F to use.
RED plate -> PRESSION PLATE, trigger, stand over it to activate related element.
GREEN zone -> Trigger to next level.

::: CONTROLS :::

W,A,S,D -> Movement
R -> Start recording actios for the clone.
F -> Use buttons.
X -> Delete the last clone created.
