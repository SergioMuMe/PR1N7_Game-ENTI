#### DATOS DEL GRUPO ####
Nombre juego: PR1N7
Miembros: Roger Buj�n, Marc Caymel, Sergio Murillo

#### LINK A YOUTUBE - GAMEPLAY ####
https://www.youtube.com/watch?v=13uM9iKPsVs

#### CONTROLES ####

W,S,A,D | flechas -> Movimiento.
Barra espaciadora -> Saltar.
F -> Pulsar botones de pared.

R -> Grabar movimientos. Genera un clon que lo reproduce.
X -> Destruir primer clon creado.
C -> Destruir �ltimo clon creado.

#### CHEATS ####

O (vocal) -> Saltar el nivel actual. (puede romper estadisticas del jugador).
L -> Fast reset del nivel. Evitas pasar por menu de pausa
